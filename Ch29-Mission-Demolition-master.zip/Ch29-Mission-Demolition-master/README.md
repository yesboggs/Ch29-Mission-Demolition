# Ch29---Mission-Demolition
Gibson - Mission Demolition

The project has the base objects for vertical and horizontal castle walls, the ground and several materials. You also have the Cloudcrafter script and clouds already implemented. Feel free to modify the cloud prefabs.

You should still look at the cloud crafter script, it just isn't going to be the focus of our work this semester.
